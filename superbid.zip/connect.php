<?php

$con = new mysqli('localhost','root','','superbid');

if(!$con){
    die(mysqli_error($con));
}

?>